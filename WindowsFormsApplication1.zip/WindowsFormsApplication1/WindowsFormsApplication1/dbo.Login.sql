﻿CREATE TABLE [dbo].[Login] (
    [Username]      VARCHAR (50) NOT NULL,
    [Password]      VARCHAR (50) NOT NULL,
    [FirstNAme]     VARCHAR (50) NOT NULL,
    [MiddleInitial] VARCHAR (50) NOT NULL,
    [LastName]      VARCHAR (50) NOT NULL,
    [Gender]        VARCHAR (50) NOT NULL,
    [Email]         VARCHAR (50) NOT NULL,
    [Contact]       VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([Username])
);

