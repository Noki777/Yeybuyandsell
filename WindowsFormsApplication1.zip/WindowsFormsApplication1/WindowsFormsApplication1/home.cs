﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using WindowsFormsApplication1.Class;

namespace WindowsFormsApplication1
{
    public partial class home : Form
    {
        public home()
        {
            InitializeComponent();
            label1.Text = LoginInfo.UserID;
        }



        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            buy buy = new buy();
            buy.Show();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            accnt back = new accnt();
            back.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            login logout = new login();
            logout.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            seller sell = new seller();
            sell.Show();
        }
    }
}
