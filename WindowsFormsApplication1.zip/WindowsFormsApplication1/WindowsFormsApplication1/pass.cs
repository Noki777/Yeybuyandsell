﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class pass : Form
    {
        public pass()
        {
            InitializeComponent();
        }
        private SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\LENOVO\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30;");
        private void button1_Click(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Login where Username  ='" + textBox2.Text + "' and Password = '" + textBox1.Text + "'", con);
            DataTable data = new DataTable();
            sda.Fill(data);
            errorProvider1.Clear();

            if (data.Rows[0][0].ToString() == "1")
            {
                if (textBox3.Text == textBox4.Text)
                {
                    string query = ("update Login set Password= '" + textBox3.Text + "' where Username= '" + textBox2.Text + "'  and Password = '" + textBox1.Text + "' ");
                    SqlCommand cmd1 = new SqlCommand(query, con);

                    con.Open();
                    cmd1.ExecuteNonQuery();
                    MessageBox.Show("Your Password Changed");
                    con.Close();
                }
                else
                {
                    errorProvider1.SetError(textBox3, "Unmatch Password");
                    errorProvider1.SetError(textBox4, "Unmatch Password");
                }


            }
            else
            {
                errorProvider1.SetError(textBox2, "Incorrect Username");
                errorProvider1.SetError(textBox1, "Incorrect Password");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            accnt back1 = new accnt();
            back1.Show();
        }
    }
}
