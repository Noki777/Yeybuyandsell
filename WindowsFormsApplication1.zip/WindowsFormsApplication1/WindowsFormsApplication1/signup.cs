﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class signup : Form
    {
        private SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\LENOVO\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30;");


        public signup()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            login back = new login();
            back.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string gender = string.Empty;
            if (radioButton1.Checked)
            {
                gender = "M";
            }
            else
            {
                gender = "F";
            }

            string query = ("Insert into Login(Username, Password, FirstName, MiddleInitial, LastName, Gender, Email, Contact, Address) values ('"
                + textBox4.Text + "', '" + textBox5.Text + "','" +
                textBox1.Text + "', '" + textBox2.Text + "', '" + textBox3.Text + "','" + 
                gender + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "')");

            SqlCommand cmd1 = new SqlCommand(query, con);

            con.Open();
            cmd1.ExecuteNonQuery();
            MessageBox.Show("Congrats! Your Registered");
            con.Close();

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
