﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class seller : Form
    {
        private SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\LENOVO\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30;");
        public seller()
        {
            InitializeComponent();
        }

        private byte[] imagebyte;

        private void button1_Click(object sender, EventArgs e)
        {
            //string imageLocation = "";
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "jpg file(*.jpg)|*.jpg| PNG files(*.png)|*.png| All Files(*,*)|*,*";
                var filename = "";

                if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    filename = dialog.FileName;
                }

                image1.Image = Image.FromFile(filename);
                FileInfo fi_image = new FileInfo(filename);
                var file_length = fi_image.Length;
                FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.Read);
                imagebyte = new byte[Convert.ToInt32(file_length)];
                fs.Read(imagebyte, 0, Convert.ToInt32(file_length));
                fs.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error Occured", "Error" + ex, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            string query = ("Insert into Items Values (@picture, @description, @price, @category)");

            SqlCommand cmd1 = new SqlCommand(query, con);

            cmd1.Parameters.Add("@picture", SqlDbType.Image);
            cmd1.Parameters["@picture"].Value = imagebyte;
            cmd1.Parameters.Add("@description", SqlDbType.VarChar);
            cmd1.Parameters["@description"].Value = textBox1.Text;
            cmd1.Parameters.Add("@price", SqlDbType.Int);
            cmd1.Parameters["@price"].Value = textBox3.Text;
            cmd1.Parameters.Add("@category", SqlDbType.VarChar);
            cmd1.Parameters["@category"].Value = comboBox1.Text;
            //cmd1.ExecuteScalar();


            //image1.Image.Save();
            cmd1.ExecuteNonQuery();
            
            con.Close();

            MessageBox.Show("Your Item Uploaded");
        }

        private void seller_Load(object sender, EventArgs e)
        {
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            home back4 = new home();
            back4.Show();
        }
    }
}
