﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1.Class;

namespace WindowsFormsApplication1
{
    public partial class accnt : Form
    {
        private SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\LENOVO\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30;");

        private readonly string _userId; 

        public accnt()
        {
            InitializeComponent();
            _userId = LoginInfo.UserID;

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            try
            {
                string selectSql = "Select * From Login where Username = '" + _userId + "'";
                SqlCommand com = new SqlCommand(selectSql, con);


                con.Open();

                using (SqlDataReader reader = com.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        textBox1.Text = (reader["FirstName"].ToString());
                        textBox2.Text = (reader["MiddleInitial"].ToString());
                        textBox3.Text = (reader["LastName"].ToString());
                        textBox4.Text = (reader["Username"].ToString());
                        textBox6.Text = (reader["Email"].ToString());
                        textBox7.Text = (reader["Contact"].ToString());

                    }
                }
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

            }
            
        }

        private void GetUserInfo(string userInfo)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "update Login set Username= '"+ textBox4.Text + 
            "',FirstName= '" + textBox1.Text + "', MiddleInitial= '" + textBox2.Text + "', LastName='" + textBox3.Text + 
            "', Email= '" + textBox6.Text + "', Contact= '" + textBox7.Text + "' where Username= '" + _userId +"'";
        
            SqlCommand cmd1 = new SqlCommand(query, con);

            con.Open();
            cmd1.ExecuteNonQuery();
            MessageBox.Show("Account Updated!");
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            pass change = new pass();
            change.Show();

        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            this.Hide();
            home home = new home();
            home.Show();
        }
    }
}
