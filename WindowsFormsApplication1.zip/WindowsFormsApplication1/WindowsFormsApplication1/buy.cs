﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class buy : Form
    {
        private SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\LENOVO\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30;");
        public buy()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            home back3 = new home();
            back3.Show();
        }

        private void mens_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();

            var category = comboBox1.Text;

            Random rnd = new Random();
            rnd.Next();

            cmd = new SqlCommand("select Top 1 Picture from Items where Category = '" + category + "' ORDER BY NEWID()", con);

            //SqlDataAdapter da = new SqlDataAdapter(cmd);

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                byte[] test;
                while (reader.Read())
                {
                    test = ((byte[])reader["Picture"]);





                    MemoryStream ms = new MemoryStream(test);
                    ms.Seek(0, SeekOrigin.Begin);

                    pictureBox1.Image = Image.FromStream(ms);
                }
            }


            con.Close();
        }
       

        SqlCommand cmd;
        private void button4_Click(object sender, EventArgs e)
        {

            

            con.Open();

            var category = comboBox1.Text;

            cmd = new SqlCommand("select Top 1 Picture from Items where Category = '"+ category + "' ", con);

            //SqlDataAdapter da = new SqlDataAdapter(cmd);

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                byte[] test;
                while (reader.Read())
                {
                    test = ((byte[])reader["Picture"]);





                    MemoryStream ms = new MemoryStream(test);
                    ms.Seek(0, SeekOrigin.Begin);

                    pictureBox1.Image = Image.FromStream(ms);
                }
            }




                //DataSet ds = new DataSet();

                //da.Fill(ds);

                //if (ds.Tables[0].Rows.Count > 0)

                //{

                //    var test = (byte[])ds.Tables[0].Rows[0]["Picture"];

                //    MemoryStream ms = new MemoryStream(test);

                //    pictureBox1.Image = Image.FromStream(ms);

                //}
                con.Close();
        }

    }

}
   
