﻿namespace WindowsFormsApplication1.Class
{
    public static class LoginInfo
    {
        public static string UserID;

    }

    public static class UserInfo
    {
        public static string UserINFO;

    }
}
