﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1.Class
{
    public class Items
    {
        public int Index { get; set; }
        public byte[] imageByte { get; set; }
    }
}
